#if 0
	distrib.h
	preprocessor defs for distributed computing
	(included by both Fortran and C)
	this file is part of FormCalc
	last modified 6 Jan 16 th
#endif


#if 0
#define SIMD 0
#else
#include "simd.h"
#endif

