#define DEPS
#define SQUAREDME

#include "decl.h"
#include "inline.h"
#include "contains.h"

#include "decl.h"
#include "inline.h"
#include "contains.h"

