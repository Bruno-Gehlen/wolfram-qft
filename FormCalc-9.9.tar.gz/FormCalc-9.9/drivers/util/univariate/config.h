* config.h
* limits for the univariate integration routines
* this file is part of FormCalc
* last modified 9 Aug 11 th

#include "types.h"


* the maximum number of components of the integrand vector

#define MAXCOMP 4

