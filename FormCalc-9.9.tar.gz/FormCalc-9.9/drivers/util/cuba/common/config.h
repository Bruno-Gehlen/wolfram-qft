#define HAVE_LONG_DOUBLE

#define HAVE_ERF

#define HAVE_FORK

#define HAVE_ALLOCA_H


#ifndef __CYGWIN__

#define HAVE_POWL

#define HAVE_SHMGET

#define HAVE_GETLOADAVG

#endif

