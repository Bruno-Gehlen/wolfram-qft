#if 0
	user.h
	the model declarations should be inserted here
	as well as any kind of user definition
	this file is part of FormCalc
	last modified 6 Oct 19 th
#endif


#ifndef USER_H
#define USER_H
// declarations for the whole file (e.g. preprocessor defs)

#define NINJA
//#define SAMURAI
//#define CUTTOOLS

#include "model.hc"

#else
// declarations for every subroutine

//#include "opp.h"

#endif

