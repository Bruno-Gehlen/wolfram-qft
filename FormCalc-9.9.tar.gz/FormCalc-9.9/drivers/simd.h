#if 0
	vectorization ability of ifort on osmin
	determined by ./configure on Tue May  1 09:53:15 CEST 2018
#endif

#define SIMD 2

