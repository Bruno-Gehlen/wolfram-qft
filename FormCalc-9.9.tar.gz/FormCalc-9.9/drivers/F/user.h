* user.h
* the model declarations should be inserted here
* as well as any kind of user definition
* this file is part of FormCalc
* last modified 6 Oct 19 th


#ifndef USER_H
#define USER_H
* declarations for the whole file (e.g. preprocessor defs)

#define NINJA
c#define SAMURAI
c#define CUTTOOLS

#else
* declarations for every subroutine

c#include "opp.h"
#include "model.Fh"

#endif

