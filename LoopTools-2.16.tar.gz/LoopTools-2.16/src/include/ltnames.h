	character*6 paraname(Pee,1:5)
	common /paranames/ paraname

	character*10 coeffname(Nee,1:5)
	common /coeffnames/ coeffname
